#include <stdio.h>
#include "ContributionCalculate.h"

int main() {
    searchCommitInformationByHashVal("6c1977");
    searchCommitInformationByHashVal("8b120821");

    return 0;
}
