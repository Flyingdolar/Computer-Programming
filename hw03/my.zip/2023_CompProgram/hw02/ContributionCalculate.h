#pragma once
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

void searchCommitInformationByHashVal(const char *hashVal);
void searchMonthlyContribution(const char *monthAbbrev);
