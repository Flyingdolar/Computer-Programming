#pragma once
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int32_t strinsert(char **ppResult, const char *pStr1, int32_t location, const char *pStr2);
